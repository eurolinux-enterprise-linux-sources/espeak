
This is a Virtual C++ project for the Windows SAPI5
version of eSpeak.

Copy the program source files from the Linux "src"
directory into this "src" directory, EXCEPT for:
  speech.h
  StdAfx.h
  stdint.h
Keep the Windows versions of these files.


Compiling the espeakedit program.

Copy the source files into directory "src", but not overwrite files:
  speech.h
  StdAfx.h

There are copies of these in directory "src_copy".


Use the  "Unicode Release" build configuration.
This linkls with the "Unicode Release" version of the wxWidgets libraries.
